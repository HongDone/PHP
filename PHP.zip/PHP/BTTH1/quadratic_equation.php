<?php
class quadratic_equation{
    private $a, $b, $c;
    //ax^2 + bx + c
    public function __construct($a, $b, $c){
        $this->a = $a;
        $this->b = $b;
        $this->c = $c;
    }
    public function solve_equation(){
        if ($this->a == 0){
            echo "Hệ số a = 0 nên phương trình sai. <br>";
        }
        else{
            $delta = pow($this->b, 2)-(4*$this->a*$this->c);
            if ($delta<0) echo "Phương trình vô nghiệm. <br>";
            else {
                if ($delta==0) echo "Phương trình có 1 nghiệm duy nhất là: ".$this->b/(2*$this->a)."<br>";
                else {
                    echo "Phương trình có 2 nghiệm phân biệt: <br>";
                    echo "x1 = ".round((-($this->b+sqrt($delta))/(2*$this->a)),3)."<br>";
                    echo "x2 = ".round((-($this->b-sqrt($delta))/(2*$this->a)), 3);
                }
            }
        }
    }
}
?>