<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="#" method = "GET">
        <table align="center" border = "1">
            <tr>
                <td style="width: 30%;">Hệ số a</td>
                <td><input type="number" name = "coef_a"></td>
            </tr>
            <tr>
                <td>Hệ số b</td>
                <td><input type="number" name = "coef_b"></td>
            </tr>
            <tr>
                <td>Hệ số c</td>
                <td><input type="number" name = "coef_c"></td>
            </tr>
            <tr>
                <td colspan="2" style = "text-align:center">
                    <input type="submit" name = "submit" value = "Giải">
                </td>
            </tr>
        </table>
        <br>
        <?php
        include("/xampp/htdocs/PHP/BTTH1/quadratic_equation.php");
        if (isset($_GET['submit'])&&$_GET['submit']=="Giải"){
            $a = (float)$_GET["coef_a"];
            $b = (float)$_GET["coef_b"];
            $c = (float)$_GET["coef_c"];
            $equa = new quadratic_equation($a,$b,$c);
            $equa->solve_equation();
        }
        ?>
    </form>
</body>
</html>