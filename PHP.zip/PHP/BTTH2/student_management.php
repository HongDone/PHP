<?php
class student_array{
    private $arr = array();
    public function __construct(array $initialData = array()){
       $this->arr = $initialData;
    }
    public function count(){
        return count($this->arr);
    }
    public function printAll(){
        foreach ($this->arr as $key => $value){
            echo "$key  $value <br>";
        }
    }
    public function printAboveXOnly($age){
        foreach ($this->arr as $key => $value){
            if ($value > $age)
            echo "$key  $value <br>";
        }
    }
    public function findByName($search){
        if (array_key_exists($search, $this->arr)) {
            return true; 
        } else {
            return false; 
        }
    }
    public function sortByAgeAsc(){
        uasort($this->arr, function ($a, $b) {
            return $a - $b;
        });      
    }
    public function addAnElementOnLast($key, $value){
        $this->arr[$key] = $value;
        echo "Đã thêm.";
    }
    public function findByAge($search){
        $res = new student_array();
        $ages = array_values($this->arr);
        $names = array_keys($this->arr);
        for ($i = 0; $i<count($this->arr); $i++){
            if ($search == $ages[$i]){
                $res->arr[$names[$i]] = $ages[$i];
            }
        }
        return $res;
    }
    public function deleteByName($target){
        if (array_key_exists($target, $this->arr)) {
            unset($this->arr[$target]);
            return true; 
        } else {
            return false; 
        }
    }
}
?>