<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <style>
        body{
            display: flex;
        }
        .con-1{
            width: 50%;
        }
        input[type = "submit"]{
            cursor: pointer;
        }
    </style>
    <div class = "con-1">
    <form action="" method = "GET">
        <span>Nhập tên cần tìm: </span>
        <input type="text" name = "search-name">
        <input type="submit" name = "submit-button" value = "Tìm theo tên">
    </form>
    <br>
    <form action="" method = "GET">
        <span>Nhập tuổi cần tìm: </span>
        <input type="number" min = 0 name = "search-age">
        <input type="submit" name = "submit-button" value = "Tìm theo tuổi">
    </form>
    <br>
    <form action="" method = "POST">
        <span>Nhập tên cần xóa: </span>
        <input type="text" name = "delete-name">
        <input type="submit" name = "submit-button" value = "Xóa">
    </form>
    <br>
    <form action="" method = "GET">
        <input type="submit" name = "submit-button" value = "Xuất danh sách">
    </form>
    <br>
    <form action="" method = "GET">
        <input type="submit" name = "submit-button" value = "Xuất danh sách sinh viên hơn 20 tuổi">
    </form>
    <br>
    <form action="" method = "GET">
        <input type="submit" name = "submit-button" value = "Sắp xếp tăng dần theo tuổi">
    </form>
    <br>
    <form action="" method = "POST">
        <span>Nhập tên sinh viên cần thêm: </span>
        <input type="text" name = "input-name">
        <br>
        <br>
        <span>Nhập tuổi sinh viên cần thêm: </span>
        <input type="number" min = 1 name = "input-age">
        <br>
        <input type="submit" name = "submit-button" value = "Thêm">
        <br>
    </form>
    <br>
    </div>
    <div class = "con-2">
    <?php
    include("/xampp/htdocs/PHP/BTTH2/student_management.php");
    session_start();
    $studentsData = array(
        "Tuấn" => 21,
        "Tú" => 19,
        "Tâm" => 22,
        "Tùng" => 20
    );
    if (!isset($_SESSION['students'])) {
        $_SESSION["students"] = new student_array($studentsData);;
    }
    if (isset($_GET["submit-button"])&&$_GET["submit-button"]=="Tìm theo tên"){
        $searchKey = $_GET["search-name"];
        if ($_SESSION["students"]->findByName($searchKey)){
            echo "$searchKey có trong danh sách.";
        }
        else  echo "$searchKey không có trong danh sách.";
    }
    if (isset($_GET["submit-button"])&&$_GET["submit-button"]=="Tìm theo tuổi"){
        $searchKey = $_GET["search-age"];
        $res = $_SESSION["students"]->findByAge($searchKey);
        $count = $res->count();
        if ($count==0){
            echo "Không có sinh viên nào $searchKey tuổi.";
        }
        else {
            if ($count == 1){
                echo "Có một sinh viên $searchKey tuổi: <br>";
                $res->printAll();
            }
            else {
                echo "Có $count sinh viên $searchKey tuổi: <br>";
                $res->printAll();
            }
        }
    }
    if (isset($_POST["submit-button"])&&$_POST["submit-button"]=="Xóa"){
        $target = $_POST["delete-name"];
        if ($_SESSION["students"]->deleteByName($target))
        echo "Đã xóa những sinh viên có tên $target.";
        else echo "Danh sách không tồn tại $target.";
    }
    if (isset($_GET["submit-button"])&&$_GET["submit-button"]=="Xuất danh sách"){
        echo "Danh sách sinh viên: <br>";
        $_SESSION['students'] -> printAll();
    }
    if (isset($_GET["submit-button"])&&$_GET["submit-button"]=="Xuất danh sách sinh viên hơn 20 tuổi"){
        echo "Danh sách sinh viên hơn 20 tuổi: <br>";
        $_SESSION["students"]->printAboveXOnly(20);
    }
    if (isset($_GET["submit-button"])&&$_GET["submit-button"]=="Sắp xếp tăng dần theo tuổi"){
        $_SESSION["students"]->sortByAgeAsc();
        echo "Danh sách đã được sắp xếp: <br>";
        $_SESSION["students"]->printAll();
    }
    if (isset($_POST["submit-button"])&&$_POST["submit-button"]=="Thêm"){
        $name = $_POST["input-name"];
        $age = $_POST["input-age"];
        $_SESSION['students']->addAnElementOnLast($name,$age);
    }
    ?>
    </div>
</body>
</html>
</body>
</html>