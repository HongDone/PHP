function checkValidValue(e){
    var inputValue = e.value;
    if (!/^\d+$/.test(inputValue)) {
        // Nếu giá trị không phải là số nguyên dương, xóa giá trị và hiển thị thông báo lỗi
        e.value = inputValue.replace(/[^\d]+/g, '');
    } 
    if (inputValue[0]=="0"&&inputValue.length!==1){
        e.value = inputValue.slice(1);
    }
    if (e.name == "month"){
        minValue = 1;
        maxValue = 12;
        if(parseInt(inputValue)<1){
            window.alert("Month can't be set less than "+minValue);
            e.value = '';
        }
        if (parseInt(inputValue)>12){
            window.alert("Month can't be set greater than "+maxValue);
            e.value = inputValue.slice(0,-1);
        }
    }
    if (e.name == "day"){
        month = parseInt((document.getElementsByName("month")[0].value));
        minValue = 1;
        if(parseInt(inputValue)<1){
            window.alert("Day can't be set less than "+minValue);
            e.value = '';
        }
        var maxValue;
        switch(month){
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                maxValue = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11: 
                maxValue = 30;
                break;
            case 2: {
            isLeap = isLeapYear(parseInt(document.getElementsByName("year")[0].value));
            if (isLeap) maxValue = 29;
            else maxValue = 28;
            }
        }
        if(parseInt(inputValue)>maxValue){
            window.alert("Day can't be set greater than "+maxValue);
            e.value = inputValue.slice(0,-1);
        }
    }
    function isLeapYear(year){
        if ((year%4==0&&year%100!=0)||year%400==0) return true;
        else return false;
    }
}
