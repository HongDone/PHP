<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <form action="#" method = "GET">
    <table align="center" border = "1">
        <tr>
            <td style="width: 30%;">Year</td>
            <td><input type="text" oninput="checkValidValue(this)" name = "year" value = 2000></td>
        </tr>
        <tr>
            <td>Month</td>
            <td><input type="text" oninput="checkValidValue(this)" name = "month" value = 1></td>
        </tr>
        <tr>
            <td>Day</td>
            <td><input type="text" oninput="checkValidValue(this)" name = "day"></td>
        </tr>
        <tr>
            <td colspan = "2" style = "text-align:center">
                <input type="submit" name = "Submit" value = "Total">
            </td>
        </tr>
    </table>
    <br>
    <?php
    if(isset($_GET['Submit'])&&$_GET['Submit']=="Total"){
        $year = (int)($_GET['year']);
        $month = (int)($_GET['month']);
        $day = (int)($_GET['day']);
        $count = $day;
        for ($i = 1; $i<$month; $i++){
            switch ($i) {
                case 1:
                case 3:
                case 5:
                case 7:
                case 8:
                case 10:
                case 12:
                    $count+=31;
                    break;
                case 4:
                case 6:
                case 9:
                case 11:
                    $count+=30;
                    break;
                case 2:
                    {
                    if (isLeapYear($year)) 
                        $count+=29;
                    else $count+=28;
                    break;
                    }
            }
        
        }
        echo "Total days from the start of the year: ".$count;
    }
    function isLeapYear($year){
        if(($year%4==0&& $year%100!=0)||$year%400==0)
        return true;
        return false;
    }
     ?>
    </form>
    <script src="script.js"></script>
</body>
</html>