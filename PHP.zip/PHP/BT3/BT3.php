<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method = "GET">
        <span>Nhập tên cần tìm: </span>
        <input type="text" name = "input-name">
        <br>
        <input type="submit" name = "submit-button" value = "Tìm">
    </form>
    <?php
    $ban = array("Tuấn" => 21, "Tú" => 19, "Tâm" => 22, "Tùng" => 20);
    $names = array_keys($ban);
    if (isset($_GET["submit-button"]) && $_GET["submit-button"]==="Tìm"){
        $search = $_GET["input-name"];
        if (findByName($names, $search)==true)
        {
            echo "Tìm thấy ".$search." trong mảng <br>";
            printArray($ban);
        }
        else echo "Không tìm thấy ".$search." trong mảng";
    }
    function printArray($arr){
        foreach ($arr as $key => $value){
            echo "$key  $value <br>";
        }
    }
    function findByName($names, $search){
        $isFound = false;
        for ($i = 0; $i < count($names); $i++){
            if ($names[$i]==$search){
                $isFound = true;
                break;
            }
        }
        return $isFound;
    }
    ?>
</body>
</html>