<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="#" method = "GET">
    <span>Chiều dài: </span>
    <input type="input" name = "length">
    <br>
    <br>
    <span>Chiều rộng: </span>
    <input type="input" name = "width">
    <br>
    <br>
    <span>Chiều cao: </span>
    <input type="input" name = "height">
    <br>
    <br>
    <input type="submit" name = "submit" value = "Tính">
    </form>
    <br>
    <?php
    include("/xampp/htdocs/PHP/BT5/rectangle_box.php");
    if (isset($_GET["submit"])&&($_GET["submit"]=="Tính")){
        $rec_box = new rectangle_box((float)$_GET["length"], (float)$_GET["width"],(float)$_GET["height"] );
        echo "Diện tích: ".$rec_box->area()."<br>";
        echo "Thể tích: ".$rec_box->volumn();
    }
    ?>
</body>
</html>