<?php
    include("/xampp/htdocs/PHP/BT4/rectangle.php");
    class rectangle_box extends rectangle{
        private $height;
        public function __construct($l, $w, $h){
            parent::__construct($l, $w);
            $this->height= $h;
        }
        public function area(){
            return parent::perimeter()*$this->height+parent::area()*2;
        }
        public function volumn(){
            return parent::area()*$this->height;
        }
    }
?>