<?php
class rectangle
{
    private $length, $width;
    public function __construct($l, $w)
    {
        $this->length = $l;
        $this->width = $w;
    }
    public function perimeter()
    {
        return ($this->length + $this->width) * 2;
    }
    public function area()
    {
        return $this->length * $this->width;
    }
}
 ?>