<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class = "container">
        <h3>Tính diện tích và chu vi hình chữ nhật</h3>
        <form action="#" method="GET" name = "rectangle">
            <table align="center" border="1">
                <tr>
                    <td style="width: 45%;">Chiều dài</td>
                    <td style="width: 45%;"><input type="number" min = "0.001" step = "0.001"  name = "length"></td>
                </tr>
                <tr>
                    <td>Chiều rộng</td>
                    <td><input type="number" min = "0.001" step = "0.001" name = "width"></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name = "Submit" value = "Tính">
                </td>
                </tr>
            </table>
            <br>
           <?php
           include ("/xampp/htdocs/PHP/BT4/rectangle.php");
            if (isset($_GET['Submit'])&&($_GET['Submit']=="Tính")){
                $rec = new rectangle((float)$_GET['length'], (float)$_GET['width']);
                echo "Diện tích = ".$rec->area()."<br>";
                echo "Chu vi = ".$rec->perimeter();
            };
            ?> 
        </form>    
    </div>
</body>
</html>